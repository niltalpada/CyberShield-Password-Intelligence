# 🛡️ CyberShield Password Intelligence

Advanced Password Strength Analyzer & Secure Password Generator.

## Features

- Real-time password analysis
- Crack time estimation
- Password complexity scoring
- AI-powered recommendations
- Secure password generator
- Interactive charts
- Modern cyber-themed UI
- Educational security guidelines
- Responsive design

## Technologies Used

- Python
- Streamlit
- zxcvbn
- Pandas
- Plotly

## Installation

```bash
pip install -r requirements.txt
streamlit run app.py