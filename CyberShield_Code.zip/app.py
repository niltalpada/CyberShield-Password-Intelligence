import streamlit as st
from zxcvbn import zxcvbn
import random
import string
import pandas as pd
import plotly.express as px

st.set_page_config(
    page_title="CyberShield Password Intelligence",
    page_icon="🛡️",
    layout="wide"
)

# ---------------- HEADER ----------------
st.markdown(
    """
    <h1 style='text-align:center;color:#4FC3F7;'>
    🛡️ CyberShield Password Intelligence
    </h1>
    <h4 style='text-align:center;color:gray;'>
    Advanced Password Strength Analyzer & Generator
    </h4>
    <hr>
    """,
    unsafe_allow_html=True
)

# ---------------- PASSWORD ANALYZER ----------------
st.header("🔍 Password Analyzer")

password = st.text_input(
    "Enter Password",
    type="password"
)

if password:

    result = zxcvbn(password)

    score = result["score"]
    crack_time = result["crack_times_display"]["offline_slow_hashing_1e4_per_second"]

    labels = [
        "Very Weak",
        "Weak",
        "Fair",
        "Strong",
        "Very Strong"
    ]

    colors = [
        "red",
        "orange",
        "gold",
        "lightgreen",
        "green"
    ]

    st.subheader(
        f"Strength: {labels[score]}"
    )

    st.progress((score + 1) / 5)

    st.markdown(
        f"**Estimated crack time:** {crack_time}"
    )

    st.subheader("💡 Recommendations")

    feedback = result["feedback"]

    if feedback["warning"]:
        st.warning(feedback["warning"])

    if feedback["suggestions"]:
        for item in feedback["suggestions"]:
            st.write("✅", item)
    else:
        st.success("Excellent password!")

    # ---------------- CHART ----------------

    chart_data = pd.DataFrame({
        "Metric": [
            "Score",
            "Remaining"
        ],
        "Value": [
            score + 1,
            5 - (score + 1)
        ]
    })

    fig = px.pie(
        chart_data,
        values="Value",
        names="Metric",
        title="Password Security Level"
    )

    st.plotly_chart(fig, use_container_width=True)

# ---------------- GENERATOR ----------------

st.markdown("---")
st.header("🔐 Secure Password Generator")

length = st.slider(
    "Password Length",
    8,
    32,
    16
)

if st.button("Generate Password"):

    chars = (
        string.ascii_letters
        + string.digits
        + "!@#$%^&*()_+-="
    )

    generated = "".join(
        random.choice(chars)
        for _ in range(length)
    )

    st.code(generated)

# ---------------- SECURITY TIPS ----------------

st.markdown("---")
st.header("🛡️ Cyber Security Tips")

tips = [
    "Use at least 12 characters.",
    "Never reuse passwords.",
    "Enable two-factor authentication.",
    "Use password managers.",
    "Avoid personal information in passwords.",
    "Change critical passwords regularly."
]

for tip in tips:
    st.write("✅", tip)

# ---------------- FOOTER ----------------

st.markdown("---")

st.markdown(
    """
    <center>
    <h4>CyberShield Password Intelligence</h4>
    <p>Developed using Python, Streamlit, zxcvbn, Pandas and Plotly</p>
    <p>Educational Cybersecurity Project</p>
    </center>
    """,
    unsafe_allow_html=True
)